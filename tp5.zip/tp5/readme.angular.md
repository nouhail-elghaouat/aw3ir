TP5

Application Metéo
Avec VueJS et openweathermap

* Vérifier si Nodejs est installé sur votre poste:
    * lancer un terminal (invite de commandes), puis lancer la commande
    ```cmd
    >npm -v
    ```
    * Si nodejs est installé, le terminal vous affichera la version de celui-ci
    ```cmd
    >npm -v
    3.10.10
    ```

* Sinon Installer Nodejs: https://nodejs.org/en/download/
        * Cliquer sur Windows Installer ou Macintosh Installer

* Installer l'outil ng-cli qui permet de créer un projet Angular via le terminal (ligne de commande)
    * Suivre ce tutoriel officiel: https://angular.io/guide/quickstart
        
* Créer une première page
    * un formulaire d'authentification
        * Identifiant (type: text de 8 caractères)
        * Mot de passe

    * Créer une méthode qui valider le formulaire, si celui est valide on dirigera l'utilisateur vers la page ```/home```


